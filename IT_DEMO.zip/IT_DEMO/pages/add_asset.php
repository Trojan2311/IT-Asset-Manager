<?php
include '../includes/db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $item_type = $_POST['item_type'];
    $make = $_POST['make'];
    $model = $_POST['model'];
    $serial_no = $_POST['serial_no'];
    $location = $_POST['location'];
    $status = $_POST['status'];
    $received_date = $_POST['received_date'];

    // Get the next available sequential ID
    $result = $conn->query("SELECT MAX(id) AS max_id FROM assets");
    $row = $result->fetch_assoc();
    $next_id = ($row['max_id']) ? $row['max_id'] + 1 : 1;

    // Insert asset with manually assigned sequential ID
    $sql = "INSERT INTO assets (id, item_type, make, model, serial_no, location, status, received_date) 
            VALUES ($next_id, '$item_type', '$make', '$model', '$serial_no', '$location', '$status', '$received_date')";

    if ($conn->query($sql) === TRUE) {
        header("Location: ../index.php");
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Add Asset</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-4">
        <h2>Add New Asset</h2>
        <form method="POST">
            <div class="mb-3">
                <label>Item Type</label>
                <input type="text" name="item_type" class="form-control" required>
            </div>
            <div class="mb-3">
                <label>Make</label>
                <input type="text" name="make" class="form-control" required>
            </div>
            <div class="mb-3">
                <label>Model</label>
                <input type="text" name="model" class="form-control" required>
            </div>
            <div class="mb-3">
                <label>Serial No</label>
                <input type="text" name="serial_no" class="form-control" required>
            </div>
            <div class="mb-3">
                <label>Location</label>
                <input type="text" name="location" class="form-control" required>
            </div>
            <div class="mb-3">
                <label>Status</label>
                <select name="status" class="form-control">
                    <option value="Active">Active</option>
                    <option value="Inactive">Inactive</option>
                </select>
            </div>
            <div class="mb-3">
                <label>Received Date</label>
                <input type="date" name="received_date" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-success">Add Asset</button>
        </form>
    </div>
</body>
</html>
