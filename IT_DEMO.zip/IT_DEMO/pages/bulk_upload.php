<?php
include '../includes/db.php';
session_start();

// Ensure only admins can access this page
if (!isset($_SESSION['username']) || $_SESSION['role'] != 'admin') {
    header("Location: ../index.php");
    exit;
}

// Handle file upload
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES["csv_file"])) {
    $file = $_FILES["csv_file"]["tmp_name"];
    $handle = fopen($file, "r");

    if ($handle !== FALSE) {
        fgetcsv($handle); // Skip the first row (Header)

        while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
            $item_type = $conn->real_escape_string($data[0]);
            $make = $conn->real_escape_string($data[1]);
            $model = $conn->real_escape_string($data[2]);
            $serial_no = $conn->real_escape_string($data[3]);
            $location = $conn->real_escape_string($data[4]);
            $status = $conn->real_escape_string($data[5]);
            $received_date = $conn->real_escape_string($data[6]);

            // Get next ID manually for sequential order
            $result = $conn->query("SELECT MAX(id) AS max_id FROM assets");
            $row = $result->fetch_assoc();
            $next_id = ($row['max_id']) ? $row['max_id'] + 1 : 1;

            // Insert asset into database
            $sql = "INSERT INTO assets (id, item_type, make, model, serial_no, location, status, received_date) 
                    VALUES ($next_id, '$item_type', '$make', '$model', '$serial_no', '$location', '$status', '$received_date')";
            $conn->query($sql);
        }

        fclose($handle);
        echo "<div class='alert alert-success'>CSV file uploaded successfully!</div>";
    } else {
        echo "<div class='alert alert-danger'>Error opening CSV file.</div>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Bulk Upload Assets</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/style.css">
</head>

<body>
    <div class="container mt-4">
        <h2>Bulk Upload Assets</h2>
        <p>Upload a CSV file containing asset details.</p>
        <form method="POST" enctype="multipart/form-data">
            <div class="mb-3">
                <label>Upload CSV File</label>
                <input type="file" name="csv_file" class="form-control" accept=".csv" required>
            </div>
            <button type="submit" class="btn btn-primary">Upload</button>
            <a href="../index.php" class="btn btn-secondary">Back to Dashboard</a>
        </form>
    </div>
</body>

</html>