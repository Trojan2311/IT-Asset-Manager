<?php
include '../includes/db.php';
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

// Get total assets
$total_assets_query = "SELECT COUNT(*) as total FROM assets";
$total_assets_result = $conn->query($total_assets_query);
$total_assets = $total_assets_result->fetch_assoc()['total'];

// Get assets by status (New, Used, EOL, Resale)
$status_query = "SELECT status, COUNT(*) as count FROM assets GROUP BY status";
$status_result = $conn->query($status_query);
$status_data = [];
while ($row = $status_result->fetch_assoc()) {
    $status_data[$row['status']] = $row['count'];
}

// Get assets by type (Printers, Laptops, etc.)
$type_query = "SELECT item_type, COUNT(*) as count FROM assets GROUP BY item_type";
$type_result = $conn->query($type_query);
$type_data = [];
while ($row = $type_result->fetch_assoc()) {
    $type_data[$row['item_type']] = $row['count'];
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>IT Manager Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="../assets/style.css">

</head>
<body>
    <div class="container mt-4">
        <h2>Dashboard</h2>
        <p>Welcome, <strong><?php echo $_SESSION['username']; ?></strong></p>
        
        <div class="row">
            <!-- Total Assets -->
            <div class="col-md-4">
                <div class="card p-3 text-center bg-primary text-white">
                    <h4>Total Assets</h4>
                    <h2><?php echo $total_assets; ?></h2>
                </div>
            </div>

            <!-- Pie Chart for Asset Status -->
            <div class="col-md-6">
                <canvas id="statusChart"></canvas>
            </div>

            <!-- Bar Chart for Asset Types -->
            <div class="col-md-6">
                <canvas id="typeChart"></canvas>
            </div>
        </div>
    </div>

    <script>
        // Asset Status Pie Chart
        var ctx1 = document.getElementById('statusChart').getContext('2d');
        var statusChart = new Chart(ctx1, {
            type: 'pie',
            data: {
                labels: <?php echo json_encode(array_keys($status_data)); ?>,
                datasets: [{
                    data: <?php echo json_encode(array_values($status_data)); ?>,
                    backgroundColor: ['#ff6384', '#36a2eb', '#ffcd56', '#4bc0c0']
                }]
            }
        });

        // Asset Type Bar Chart
        var ctx2 = document.getElementById('typeChart').getContext('2d');
        var typeChart = new Chart(ctx2, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode(array_keys($type_data)); ?>,
                datasets: [{
                    label: 'Number of Assets',
                    data: <?php echo json_encode(array_values($type_data)); ?>,
                    backgroundColor: '#36a2eb'
                }]
            }
        });
    </script>
</body>
</html>
