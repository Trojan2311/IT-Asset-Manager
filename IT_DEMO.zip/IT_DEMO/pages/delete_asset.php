<?php
include '../includes/db.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Delete asset
    $delete_sql = "DELETE FROM assets WHERE id = $id";
    if ($conn->query($delete_sql) === TRUE) {

        // Reorder all IDs sequentially
        $conn->query("SET @count = 0;");
        $conn->query("UPDATE assets SET id = @count := @count + 1;");
        $conn->query("ALTER TABLE assets AUTO_INCREMENT = 1;");

        header("Location: ../index.php");
        exit;
    } else {
        echo "Error deleting record: " . $conn->error;
    }
} else {
    echo "Invalid request!";
}
?>
