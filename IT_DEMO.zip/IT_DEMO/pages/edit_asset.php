<?php
include '../includes/db.php';

// Check if ID is passed
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Fetch asset details
    $sql = "SELECT * FROM assets WHERE id = $id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
    } else {
        echo "Asset not found!";
        exit;
    }
}

// Handle form submission for update
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $item_type = $_POST['item_type'];
    $make = $_POST['make'];
    $model = $_POST['model'];
    $serial_no = $_POST['serial_no'];
    $location = $_POST['location'];
    $status = $_POST['status'];
    $received_date = $_POST['received_date'];

    // Update query
    $update_sql = "UPDATE assets SET 
                    item_type='$item_type', make='$make', model='$model', 
                    serial_no='$serial_no', location='$location', 
                    status='$status', received_date='$received_date' 
                   WHERE id=$id";

    if ($conn->query($update_sql) === TRUE) {
        header("Location: ../index.php");
        exit;
    } else {
        echo "Error updating record: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Edit Asset</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-4">
        <h2>Edit Asset</h2>
        <form method="POST">
            <div class="mb-3">
                <label>Item Type</label>
                <input type="text" name="item_type" class="form-control" value="<?php echo $row['item_type']; ?>" required>
            </div>
            <div class="mb-3">
                <label>Make</label>
                <input type="text" name="make" class="form-control" value="<?php echo $row['make']; ?>" required>
            </div>
            <div class="mb-3">
                <label>Model</label>
                <input type="text" name="model" class="form-control" value="<?php echo $row['model']; ?>" required>
            </div>
            <div class="mb-3">
                <label>Serial No</label>
                <input type="text" name="serial_no" class="form-control" value="<?php echo $row['serial_no']; ?>" required>
            </div>
            <div class="mb-3">
                <label>Location</label>
                <input type="text" name="location" class="form-control" value="<?php echo $row['location']; ?>" required>
            </div>
            <div class="mb-3">
                <label>Status</label>
                <select name="status" class="form-control">
                    <option value="Active" <?php echo ($row['status'] == "Active") ? "selected" : ""; ?>>Active</option>
                    <option value="Inactive" <?php echo ($row['status'] == "Inactive") ? "selected" : ""; ?>>Inactive</option>
                </select>
            </div>
            <div class="mb-3">
                <label>Received Date</label>
                <input type="date" name="received_date" class="form-control" value="<?php echo $row['received_date']; ?>" required>
            </div>
            <button type="submit" class="btn btn-success">Update Asset</button>
        </form>
    </div>
</body>
</html>
