<?php
include '../includes/db.php';

// Set header for CSV download
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename=IT_Assets.csv');

$output = fopen("php://output", "w");

// Add column headers
fputcsv($output, array('ID', 'Item Type', 'Make', 'Model', 'Serial No', 'Location', 'Status', 'Received Date'));

// Fetch data from database
$sql = "SELECT id, item_type, make, model, serial_no, location, status, received_date FROM assets ORDER BY id ASC";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        fputcsv($output, $row);
    }
}

fclose($output);
exit;
?>
