<?php
require '../vendor/autoload.php';
include '../includes/db.php';

use Dompdf\Dompdf;
use Dompdf\Options;

// Initialize Dompdf with options
$options = new Options();
$options->set('defaultFont', 'Helvetica');
$dompdf = new Dompdf($options);

// HTML content for PDF
$html = '<h2 style="text-align:center;">IT Asset Report</h2>';
$html .= '<table border="1" cellspacing="0" cellpadding="5" width="100%">
            <tr>
                <th>ID</th>
                <th>Item Type</th>
                <th>Make</th>
                <th>Model</th>
                <th>Serial No</th>
                <th>Location</th>
                <th>Status</th>
                <th>Received Date</th>
            </tr>';

$sql = "SELECT id, item_type, make, model, serial_no, location, status, received_date FROM assets ORDER BY id ASC";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $html .= "<tr>
                    <td>{$row['id']}</td>
                    <td>{$row['item_type']}</td>
                    <td>{$row['make']}</td>
                    <td>{$row['model']}</td>
                    <td>{$row['serial_no']}</td>
                    <td>{$row['location']}</td>
                    <td>{$row['status']}</td>
                    <td>{$row['received_date']}</td>
                  </tr>";
    }
}

$html .= '</table>';

// Load HTML into dompdf
$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'landscape');
$dompdf->render();

// Output the PDF
$dompdf->stream("IT_Assets_Report.pdf", array("Attachment" => 1));
exit;
?>
