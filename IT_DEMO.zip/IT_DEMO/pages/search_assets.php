<?php
include '../includes/db.php';

$search = isset($_POST['search']) ? $_POST['search'] : '';
$status = isset($_POST['status']) ? $_POST['status'] : '';
$warehouse = isset($_POST['warehouse']) ? $_POST['warehouse'] : '';

$sql = "SELECT * FROM assets WHERE 1=1";

if ($search != '') {
    $sql .= " AND (serial_no LIKE '%$search%' OR model LIKE '%$search%' OR asset_tag LIKE '%$search%')";
}
if ($status != '') {
    $sql .= " AND status = '$status'";
}
if ($warehouse != '') {
    $sql .= " AND location = '$warehouse'";
}

$sql .= " ORDER BY id ASC";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
            <td>{$row['id']}</td>
            <td>{$row['item_type']}</td>
            <td>{$row['make']}</td>
            <td>{$row['model']}</td>
            <td>{$row['serial_no']}</td>
            <td>{$row['location']}</td>
            <td>{$row['status']}</td>
            <td>{$row['received_date']}</td>
            <td>
                <a href='edit_asset.php?id={$row['id']}' class='btn btn-warning btn-sm'>Edit</a>
                <a href='delete_asset.php?id={$row['id']}' class='btn btn-danger btn-sm'>Delete</a>
            </td>
        </tr>";
    }
} else {
    echo "<tr><td colspan='9' class='text-center'>No assets found</td></tr>";
}
?>
